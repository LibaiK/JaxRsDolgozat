-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2022. Dec 16. 14:16
-- Kiszolgáló verziója: 10.4.24-MariaDB
-- PHP verzió: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `pizzarendeles`
--
CREATE DATABASE IF NOT EXISTS `pizzarendeles` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `pizzarendeles`;

DELIMITER $$
--
-- Eljárások
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `addNewOrder` (IN `userIdIn` INT, IN `rendelesIdejeIN` DATE)   INSERT INTO `rendeles` (`rendeles`.`userId`,`rendeles`.`rendelesIdeje`) VALUES(userIdIn,rendelesIdejeIN)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addNewPizza` (IN `pizzafajtaIN` VARCHAR(200) CHARSET utf8mb4, IN `PizzaArIN` INT)   INSERT into `pizza` (`pizza`.`pizzaFajta`,`pizza`.`PizzaAr`) VALUES(pizzafajtaIN,PizzaArIN)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addNewRendelo` (IN `idIN` INT, IN `rendeloNeveIN` VARCHAR(200) CHARSET utf8, IN `rendelotelefonszamaIN` INT, IN `rendeloEmailIN` VARCHAR(200))   INSERT INTO `rendelo` (`rendelo`.`id`,`rendelo`.`RendeloNeve`,`rendelo`.`RendeloTelefonszama`,`rendelo`.`RendeloEmail`)
VALUES (idIN,rendeloNeveIN,rendelotelefonszamaIN,rendeloEmailIN)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AllOrdersByUser` (OUT `result` VARCHAR(200) CHARSET utf8mb4, IN `statusCheck` VARCHAR(20) CHARSET utf8mb4)   SELECT COUNT(`rendelo`.`id`) INTO result FROM `rendelo` WHERE `rendelo`.`rendelesStatusza` = statusCheck$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `completedOffersByDay` (IN `statusCheck` INT, OUT `result` INT)   SELECT COUNT (`rendeles`.`rendelesIdeje`) INTO result FROM `rendelo` WHERE `rendeles`.`rendelesStatusza` = statusCheck$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllPizza` ()   SELECT * FROM `pizza`$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateOrderStatus` (IN `statusIN` BOOLEAN)   UPDATE `rendeles` SET `rendeles`.`rendelesStatusza` = statusIN$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizza`
--

CREATE TABLE `pizza` (
  `id` int(11) NOT NULL,
  `pizzaFajta` varchar(70) NOT NULL,
  `PizzaAr` int(11) NOT NULL,
  `rendelesId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `rendeles`
--

CREATE TABLE `rendeles` (
  `rendelesIdeje` date NOT NULL,
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `rendelesStatusza` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `rendelo`
--

CREATE TABLE `rendelo` (
  `id` int(11) NOT NULL,
  `RendeloNeve` varchar(200) NOT NULL,
  `RendeloTelefonszama` int(11) NOT NULL,
  `RendeloEmail` varchar(200) NOT NULL,
  `RendeleseinekSzama` int(11) NOT NULL,
  `rendelesStatusza` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rendelesId` (`rendelesId`);

--
-- A tábla indexei `rendeles`
--
ALTER TABLE `rendeles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- A tábla indexei `rendelo`
--
ALTER TABLE `rendelo`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `pizza`
--
ALTER TABLE `pizza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `rendeles`
--
ALTER TABLE `rendeles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `rendelo`
--
ALTER TABLE `rendelo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `pizza`
--
ALTER TABLE `pizza`
  ADD CONSTRAINT `pizza_ibfk_1` FOREIGN KEY (`rendelesId`) REFERENCES `rendeles` (`id`);

--
-- Megkötések a táblához `rendelo`
--
ALTER TABLE `rendelo`
  ADD CONSTRAINT `rendelo_ibfk_1` FOREIGN KEY (`id`) REFERENCES `rendeles` (`userId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
