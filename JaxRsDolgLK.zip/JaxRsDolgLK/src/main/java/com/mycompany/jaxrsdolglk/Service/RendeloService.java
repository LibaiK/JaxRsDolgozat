/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jaxrsdolglk.Service;

import com.mycompany.jaxrsdolglk.Model.Rendelo;

/**
 *
 * @author krist
 */
public class RendeloService {
    Rendelo u = new Rendelo();
    String result = "";
    public String addNewRendelo(Rendelo rendelo){
       if(u.getRendeleseinekSzama()>1){
           System.out.println("Gratulálunk ön nem először vásárol nálunk örülünk hogy tetszik a szolgáltatásunk");
       }else if(result.isEmpty()){
          result = u.addNewRendelo(rendelo);
       }else{
           System.out.println("Üdvözöljük ön friss vásárló");
               return result;
       }
       return result;
}
}
