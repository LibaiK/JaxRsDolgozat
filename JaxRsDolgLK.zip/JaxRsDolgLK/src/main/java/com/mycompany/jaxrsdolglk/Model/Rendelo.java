/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jaxrsdolglk.Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author krist
 */
@Entity
@Table(name = "rendelo")
@NamedQueries({
    @NamedQuery(name = "Rendelo.findAll", query = "SELECT r FROM Rendelo r"),
    @NamedQuery(name = "Rendelo.findById", query = "SELECT r FROM Rendelo r WHERE r.id = :id"),
    @NamedQuery(name = "Rendelo.findByRendeloNeve", query = "SELECT r FROM Rendelo r WHERE r.rendeloNeve = :rendeloNeve"),
    @NamedQuery(name = "Rendelo.findByRendeloTelefonszama", query = "SELECT r FROM Rendelo r WHERE r.rendeloTelefonszama = :rendeloTelefonszama"),
    @NamedQuery(name = "Rendelo.findByRendeloEmail", query = "SELECT r FROM Rendelo r WHERE r.rendeloEmail = :rendeloEmail"),
    @NamedQuery(name = "Rendelo.findByRendeleseinekSzama", query = "SELECT r FROM Rendelo r WHERE r.rendeleseinekSzama = :rendeleseinekSzama"),
    @NamedQuery(name = "Rendelo.findByRendelesStatusza", query = "SELECT r FROM Rendelo r WHERE r.rendelesStatusza = :rendelesStatusza")})
public class Rendelo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "RendeloNeve")
    private String rendeloNeve;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RendeloTelefonszama")
    private int rendeloTelefonszama;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "RendeloEmail")
    private String rendeloEmail;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RendeleseinekSzama")
    private int rendeleseinekSzama;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "rendelesStatusza")
    private String rendelesStatusza;
    @JoinColumn(name = "id", referencedColumnName = "userId", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Rendeles rendeles;

    public Rendelo() {
    }

    public Rendelo(Integer id) {
        this.id = id;
    }

    public Rendelo(Integer id, String rendeloNeve, int rendeloTelefonszama, String rendeloEmail, int rendeleseinekSzama, String rendelesStatusza) {
        this.id = id;
        this.rendeloNeve = rendeloNeve;
        this.rendeloTelefonszama = rendeloTelefonszama;
        this.rendeloEmail = rendeloEmail;
        this.rendeleseinekSzama = rendeleseinekSzama;
        this.rendelesStatusza = rendelesStatusza;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRendeloNeve() {
        return rendeloNeve;
    }

    public void setRendeloNeve(String rendeloNeve) {
        this.rendeloNeve = rendeloNeve;
    }

    public int getRendeloTelefonszama() {
        return rendeloTelefonszama;
    }

    public void setRendeloTelefonszama(int rendeloTelefonszama) {
        this.rendeloTelefonszama = rendeloTelefonszama;
    }

    public String getRendeloEmail() {
        return rendeloEmail;
    }

    public void setRendeloEmail(String rendeloEmail) {
        this.rendeloEmail = rendeloEmail;
    }

    public int getRendeleseinekSzama() {
        return rendeleseinekSzama;
    }

    public void setRendeleseinekSzama(int rendeleseinekSzama) {
        this.rendeleseinekSzama = rendeleseinekSzama;
    }

    public String getRendelesStatusza() {
        return rendelesStatusza;
    }

    public void setRendelesStatusza(String rendelesStatusza) {
        this.rendelesStatusza = rendelesStatusza;
    }

    public Rendeles getRendeles() {
        return rendeles;
    }

    public void setRendeles(Rendeles rendeles) {
        this.rendeles = rendeles;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rendelo)) {
            return false;
        }
        Rendelo other = (Rendelo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.jaxrsdolglk.Model.Rendelo[ id=" + id + " ]";
    }
     public boolean AllOrdersByUser(String status){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("AllOrdersByUser");
            
            spq.registerStoredProcedureParameter("result", Integer.class, ParameterMode.OUT);
            spq.registerStoredProcedureParameter("statusCheckIN", String.class, ParameterMode.IN);
            
            spq.setParameter("statusCheckIN", status);
            spq.execute();
            Integer result = Integer.parseInt(spq.getOutputParameterValue("result").toString());
            
            return result==0 ? true : false;
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
            return false;
        }
        finally{
            em.clear();
            em.close();
            emf.close();
}
     }
     public String addNewRendelo(Rendelo vendeg){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewRendelo");
        spq.registerStoredProcedureParameter("idIN", Integer.class, ParameterMode.IN);
        spq.registerStoredProcedureParameter("rendeloNeveIN", String.class, ParameterMode.IN);
        spq.registerStoredProcedureParameter("rendelotelefonszamaIN", Integer.class, ParameterMode.IN);
        spq.registerStoredProcedureParameter("rendeloEmailIN", Integer.class, ParameterMode.IN);

        
        
        
        spq.setParameter("idIN",vendeg.getId());
        spq.setParameter("rendeloNeveIN",vendeg.getRendeloNeve());
        spq.setParameter("rendelotelefonszamaIN",vendeg.getRendeleseinekSzama());
        spq.setParameter("rendeloEmailIN",vendeg.getRendeloEmail());
        
        spq.execute();
            return "Sikeres vendég felvétel!";
    }
         catch(Exception ex){
            if(ex.getMessage().equals("org.hibernate.exception.ConstraintViolationException: Error calling CallableStatement.getMoreResults")){
                return "Some unique value is duplicate!";
            }
            return ex.getMessage();
        }
        finally{
            em.clear();
            em.close();
            emf.close();
   }
 }
}
