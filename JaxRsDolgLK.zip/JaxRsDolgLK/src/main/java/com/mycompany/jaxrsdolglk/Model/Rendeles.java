/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jaxrsdolglk.Model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author krist
 */
@Entity
@Table(name = "rendeles")
@NamedQueries({
    @NamedQuery(name = "Rendeles.findAll", query = "SELECT r FROM Rendeles r"),
    @NamedQuery(name = "Rendeles.findByRendelesIdeje", query = "SELECT r FROM Rendeles r WHERE r.rendelesIdeje = :rendelesIdeje"),
    @NamedQuery(name = "Rendeles.findById", query = "SELECT r FROM Rendeles r WHERE r.id = :id"),
    @NamedQuery(name = "Rendeles.findByUserId", query = "SELECT r FROM Rendeles r WHERE r.userId = :userId"),
    @NamedQuery(name = "Rendeles.findByRendelesStatusza", query = "SELECT r FROM Rendeles r WHERE r.rendelesStatusza = :rendelesStatusza")})
public class Rendeles implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "rendelesIdeje")
    @Temporal(TemporalType.DATE)
    private Date rendelesIdeje;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "userId")
    private int userId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "rendelesStatusza")
    private boolean rendelesStatusza;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "rendelesId")
    private Collection<Pizza> pizzaCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "rendeles")
    private Rendelo rendelo;

    public Rendeles() {
    }

    public Rendeles(Integer id) {
        this.id = id;
    }

    public Rendeles(Integer id, Date rendelesIdeje, int userId, boolean rendelesStatusza) {
        this.id = id;
        this.rendelesIdeje = rendelesIdeje;
        this.userId = userId;
        this.rendelesStatusza = rendelesStatusza;
    }

    public Date getRendelesIdeje() {
        return rendelesIdeje;
    }

    public void setRendelesIdeje(Date rendelesIdeje) {
        this.rendelesIdeje = rendelesIdeje;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public boolean getRendelesStatusza() {
        return rendelesStatusza;
    }

    public void setRendelesStatusza(boolean rendelesStatusza) {
        this.rendelesStatusza = rendelesStatusza;
    }

    public Collection<Pizza> getPizzaCollection() {
        return pizzaCollection;
    }

    public void setPizzaCollection(Collection<Pizza> pizzaCollection) {
        this.pizzaCollection = pizzaCollection;
    }

    public Rendelo getRendelo() {
        return rendelo;
    }

    public void setRendelo(Rendelo rendelo) {
        this.rendelo = rendelo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rendeles)) {
            return false;
        }
        Rendeles other = (Rendeles) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.jaxrsdolglk.Model.Rendeles[ id=" + id + " ]";
    }
    public String addNewOrder(Rendeles order){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewOrder");
        spq.registerStoredProcedureParameter("userIdIN", String.class, ParameterMode.IN);
        spq.registerStoredProcedureParameter("rendelesIdejeIN", Integer.class, ParameterMode.IN);
        
        spq.setParameter("userId",order.getUserId());
        spq.execute();
            return "Sikeres rendelés felvétel!";
    }
         catch(Exception ex){
            if(ex.getMessage().equals("org.hibernate.exception.ConstraintViolationException: Error calling CallableStatement.getMoreResults")){
                return "Some unique value is duplicate!";
            }
            return ex.getMessage();
        }
        finally{
            em.clear();
            em.close();
            emf.close();
   }
 }
    public boolean completedOffersByDay(String status){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("completedOffersByDay");
            
            spq.registerStoredProcedureParameter("result", Integer.class, ParameterMode.OUT);
            spq.registerStoredProcedureParameter("statusCheckIN", String.class, ParameterMode.IN);
            
            spq.setParameter("statusCheck", status);
            spq.setParameter("statusCheckIN", status);
            spq.execute();
            Integer result = Integer.parseInt(spq.getOutputParameterValue("result").toString());
            
            return result==0 ? true : false;
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
            return false;
        }
        finally{
            em.clear();
            em.close();
            emf.close();
}
     }
    public Boolean updateOrderStatus(){
        try{
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
           EntityManager em = emf.createEntityManager();
           StoredProcedureQuery spq = em.createStoredProcedureQuery("updateOrderStatus");
           
           spq.registerStoredProcedureParameter("statusIN",String.class,ParameterMode.IN);
           
           spq.setParameter("statusIN", this.rendelesStatusza);
           
           spq.execute();
            em.clear();
            em.close();
            emf.close();
            
            return true;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
            return false;
        }  
    }
}