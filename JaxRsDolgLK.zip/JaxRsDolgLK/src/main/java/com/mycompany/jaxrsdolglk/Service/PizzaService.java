
package com.mycompany.jaxrsdolglk.Service;

import com.mycompany.jaxrsdolglk.Model.Pizza;


public class PizzaService {
    Pizza z = new Pizza();
    String result = "";
    private String Ar(String ar){
        if(z.getPizzaAr()>8000){
            System.out.println("Nem szabad ilyen drágán pizzát kiraknod");
        }else{
            System.out.println("Ügyes vagy korrekt áron raktál ki pizzát");
        }
        return result;
    }
   
}
