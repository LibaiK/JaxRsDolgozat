/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jaxrsdolglk.Model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author krist
 */
@Entity
@Table(name = "pizza")
@NamedQueries({
    @NamedQuery(name = "Pizza.findAll", query = "SELECT p FROM Pizza p"),
    @NamedQuery(name = "Pizza.findById", query = "SELECT p FROM Pizza p WHERE p.id = :id"),
    @NamedQuery(name = "Pizza.findByPizzaFajta", query = "SELECT p FROM Pizza p WHERE p.pizzaFajta = :pizzaFajta"),
    @NamedQuery(name = "Pizza.findByPizzaAr", query = "SELECT p FROM Pizza p WHERE p.pizzaAr = :pizzaAr")})
public class Pizza implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 70)
    @Column(name = "pizzaFajta")
    private String pizzaFajta;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PizzaAr")
    private int pizzaAr;
    @JoinColumn(name = "rendelesId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Rendeles rendelesId;

    public Pizza() {
    }

    public Pizza(Integer id) {
        this.id = id;
    }

    public Pizza(Integer id, String pizzaFajta, int pizzaAr) {
        this.id = id;
        this.pizzaFajta = pizzaFajta;
        this.pizzaAr = pizzaAr;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPizzaFajta() {
        return pizzaFajta;
    }

    public void setPizzaFajta(String pizzaFajta) {
        this.pizzaFajta = pizzaFajta;
    }

    public int getPizzaAr() {
        return pizzaAr;
    }

    public void setPizzaAr(int pizzaAr) {
        this.pizzaAr = pizzaAr;
    }

    public Rendeles getRendelesId() {
        return rendelesId;
    }

    public void setRendelesId(Rendeles rendelesId) {
        this.rendelesId = rendelesId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pizza)) {
            return false;
        }
        Pizza other = (Pizza) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.jaxrsdolglk.Model.Pizza[ id=" + id + " ]";
    }
     public String addNewPizza(Pizza pizza){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewPizza");
        spq.registerStoredProcedureParameter("pizzafajtaIN", String.class, ParameterMode.IN);
        spq.registerStoredProcedureParameter("PizzaArIN", Integer.class, ParameterMode.IN);
        
        
        spq.setParameter("pizzaFajta",pizza.getPizzaFajta());
        spq.setParameter("pizzaAr",pizza.getPizzaAr());
        spq.execute();
            return "Sikeresen felvetél egy új pizzát!";
    }
         catch(Exception ex){
            if(ex.getMessage().equals("org.hibernate.exception.ConstraintViolationException: Error calling CallableStatement.getMoreResults")){
                return "Some unique value is duplicate!";
            }
            return ex.getMessage();
        }
        finally{
            em.clear();
            em.close();
            emf.close();
   }
 }
    public static ArrayList<Pizza> getAllPizza(){
            ArrayList<Pizza> returnValue = new ArrayList();
            try{
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_JaxRsDolgLK_war_0.1-SNAPSHOTPU");
          EntityManager em = emf.createEntityManager();
          StoredProcedureQuery spq = em.createStoredProcedureQuery("getAllPizza");
          
        ArrayList<Object[]> result = (ArrayList<Object[]>) spq.getResultList();
        
        for(Object[] rekord : result){
            Integer id = Integer.parseInt(rekord[0].toString());
            String pizzaFajta = rekord[1].toString();
            Integer PizzaAr  = Integer.parseInt(rekord[2].toString());
            String rendelesId =  rekord[3].toString();
        }
        return returnValue;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
            return returnValue;
        }
    }
}
